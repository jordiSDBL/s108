package n1;

import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class Fase1 {

	public static void main(String[] args) {
		List<String> noms = Arrays // llista pels apartats 1, 3 i 4
				.asList("Ana", "Roc", "Mireia", "Omar", "Anna", "Amy");
		
		/*******************************************************************************
		 * APARTAT 1:
		 * Tenint una llista de cadenes de noms propis, escriu un m�tode que retorn e
		 * una llista de totes les cadenes que comencen amb la lletra 'a' (mayuscula ) i
		 * tenen exactament 3 lletres. Imprimeix el resultat .
		 ******************************************************************************/
		List<String> filtrats = noms // sobre la llista noms...
				.stream() // ...es crea l'stream
				.filter(nom -> nom.charAt(0) == 'A') // filtrem per char inicial
				.filter(nom -> nom.length() == 3) // i tamb� per qtt de chars
				.collect(Collectors.toList()); // ho recullim i s'emmagatze a la variable filtrats

		System.out.println("APARTAT 1:");
		filtrats.forEach(n -> System.out.println(n));// per a cada element, n'imprimim el valor
		//******************************************************************************//
		
		
		/********************************************************************************
		 * APARTAT 2:
		 * Escriu un m�tode que retorne una cadena separada per comes basada en una
		 * llista d�Integers. Cada element hauria d'anar precedit per la lletra "e" si
		 * el nombre �s parell , i precedit de la lletra "o" si el nombre �s im parell.
		 * Per exemple, si la llista d'entrada �s (3,44), la sortida hauria de ser "o3,
		 * e44". Imprimeix el resultat.
		 *******************************************************************************/
		System.out.println("\nAPARTAT 2:");
		List<Integer> nums = Arrays // declarem una llista d'enters
				.asList(22, 3, 90, 4, 5, 6); // i la poblem amb n�meros
		
		Consumer<Integer> composicio = n -> {
			if (n % 2 == 0) { // si s�n parells
				System.out.print("e" + String.valueOf(n)); // es passen a str i es posa "e" al davant
			} else {
				System.out.print("o" + String.valueOf(n)); // es passen a str i es posa "o" al davant
			}
			if (n != nums.get(nums.size() - 1)) { 
				System.out.print(",");// s'encadenaran amb una coma, excepte l'�ltim
			}
		};
		nums.forEach(composicio);//imprimim la variable de la interf�cie on ho hem passat
		//******************************************************************************//
		
		
		/********************************************************************************
		 * APARTAT 3:
		 * Tenint una llista de Strings, escriu un m�tode que retorne una llista de
		 * totes les cadenes que continguen la lletra �o� i imprimeix el resultat .
		 *******************************************************************************/
		System.out.println("\n\nAPARTAT 3:");
		List<String> filtratsAmbo = noms
				.stream()
				.filter(nom -> nom.contains("o") || nom.contains("O"))//filtrem
				.collect(// recollim
						Collectors.toList());//passem a llista i es desa a filtratsAmbo
		filtratsAmbo.forEach(n -> System.out.println(n));//la recorrem i imprimim
		//******************************************************************************//
		
	
		/********************************************************************************
		 * APARTAT 4:
		 * Has de fer el mateix que en el punt anterior, per� retornant una
		 * llista que incloga els elements amb m�s de 5 lletres. Imprimeix el resultat.
		 *******************************************************************************/
		System.out.println("\nAPARTAT 4:");
		List<String> filtratsMesde5 = noms
				.stream()
				.filter(nom -> nom.length()>5)// filtrem
				.collect(//recollim
						Collectors.toList());//passem a llista i es desa a filtratsMesde5
		filtratsMesde5.forEach(n -> System.out.println(n));
		//******************************************************************************//
		
		
		/********************************************************************************
		 * APARTAT 5: 
		 * Crea una llista amb els nombs dels mesos de l�any. Imprimeix tots
		 * els elements de la llista amb una lambda.
		 *******************************************************************************/
		System.out.println("\nAPARTAT 5:");
		List<String> mesosAny = Arrays.asList("gener", "febrer", "mar�", "abril", "maig", "juny", "juliol", "agost",
				"setembre", "octubre", "novembre", "desembre");
		mesosAny.forEach(n -> System.out.println(n));//impressi� amb expressi� lambda
		//******************************************************************************//
		
		
		/********************************************************************************
		 * APARTAT 6: 
		 * Has de fer la mateixa impressi� del punt anterior per� fent-ho
		 * mitjan�ant method reference.
		 *******************************************************************************/
		System.out.println("\nAPARTAT 6:");
		mesosAny.forEach(System.out::println);//impressi� amb method reference
		//******************************************************************************//
		
		
	}// fin del main
}// fi de la classe