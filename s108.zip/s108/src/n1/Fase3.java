package n1;

public class Fase3 {
	/**
	 * 1- Creem la Functional Interface
	 * 2- Hi posem un m�tode abstracte (reverse()) i posem que li passarem un string
	 * per par�metre, la paraula que voldrem girar i ens ha de retornar un String,
	 * la paraula ja girada
	 */
	@FunctionalInterface
	interface StringFunction {
		String reverse(String str);
	}
	
	public static void main(String[] args) {
		/**
		 * Instanciem la interf�cie i fem que quan es cridi el seu m�tode passan-t'hi un
		 * element, que ser� String segons la signatura del m�tode, farem servir el
		 * m�tode reverse() de StringBuilder per girar els caracters i toString per
		 * passar-ho a cadena i ja tindrem el m�tode sobreescrit
		 * 
		 */
		StringFunction interf = s -> new StringBuilder(s).reverse().toString();
		
		/**
		 * fent �s de la inst�ncia, amb el comportament ja definit, fem la crida al
		 * m�tode reverse().
		 * Imprimim el retorn per obtenir la paraula invertida per consola
		 */
		
		System.out.println(interf.reverse("paraula"));
	}
}
