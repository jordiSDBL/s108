package n1;

public class Fase2 {
	/**
	 * 1- Creem la Functional Interface
	 * 2- Hi posem un m�tode abstracte (getPiValue()) i posem que cal que ens
	 * retorni un double
	 * 
	 */
	@FunctionalInterface
	interface DoubleFunction {
		Double getPiValue();
	}

	public static void main(String[] args) {
		/**
		 * Instanciem la interf�cie i fem que quan es cridi el seu m�tode buit, sense
		 * par�metres "()", se li assignar� el que retorna el m�tode MATH.PI, que sabem
		 * que �s un double
		 */
		DoubleFunction interf = () -> Math.PI;

		/**
		 * fent �s de la inst�ncia, amb el comportament ja definit, fem la crida al
		 * m�tode getPiValue() que ara ja est� concretat.
		 * Imprimim el retorn per obtenir el n�mero Pi en consola
		 */
		System.out.println(interf.getPiValue());
	}
}
